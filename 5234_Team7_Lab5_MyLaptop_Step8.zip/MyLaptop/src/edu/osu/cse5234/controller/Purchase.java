package edu.osu.cse5234.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import edu.osu.cse5234.model.*;


@Controller
@RequestMapping("/purchase")
public class Purchase {

	@RequestMapping(method = RequestMethod.GET)
	public String viewOrderEntryForm(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// Order order = request.getAttribute("order");
		ArrayList<Item> itemList = new ArrayList<>();
		Order order = new Order();
		String name = "";
		String price = "10";
		String[] laptops = {"", "MacBook", "Lenovo", "HP", "Dell", "Thinkpad"};


		for (int i = 1; i < 6; i++) {
			Item item = new Item();
			item.setName(name + laptops[i]);
			item.setPrice(price + (i*4));
			item.setQuantity("");
			itemList.add(item);
		}
		order.setItems(itemList);
		order.setOrderNumber(itemList.size() + "");
		request.setAttribute("order", order);
		return "OrderEntryForm";
	}


	@RequestMapping(path = "/submitItems", method = RequestMethod.POST)
	public String submitItems(@ModelAttribute("order") Order order, HttpServletRequest request) {
		request.getSession().setAttribute("order", order);
		return "redirect:/purchase/paymentEntry";
	}

	@RequestMapping(path = "/paymentEntry", method = RequestMethod.GET)
	public String viewPaymentEntryPage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		PaymentInfo payment = new PaymentInfo();

		payment.setHolderName("");
		payment.setccNumber("");
		payment.setcvvCode("");
		payment.setexpDate("");
		request.setAttribute("payment", payment);
		return "PaymentEntryForm";
	}

	@RequestMapping(path = "/submitPayment", method = RequestMethod.POST)
	public String submitPayment(@ModelAttribute("payment") PaymentInfo payment, HttpServletRequest request) {
		request.getSession().setAttribute("payment", payment);
		return "redirect:/purchase/shippingEntry";
	}

	@RequestMapping(path = "/shippingEntry", method = RequestMethod.GET)
	public String viewShippingEntryPage(HttpServletRequest request, HttpServletResponse response) {
		//request.setAttribute("shipping", new ShippingInfo());
		ShippingInfo shipping = new ShippingInfo();

		shipping.setName("");
		shipping.setAddLine1("");
		shipping.setAddLine2("");
		shipping.setCity("");
		shipping.setState("");
		shipping.setZip("");
		request.setAttribute("shipping", shipping);
		return "ShippingEntryForm";
	}
	
	@RequestMapping(path = "/submitShipping", method = RequestMethod.POST)
	public String submitShipping(@ModelAttribute("shippingInfo") ShippingInfo shippingInfo,
			HttpServletRequest request) {
		request.getSession().setAttribute("shippingInfo", shippingInfo);
		return "redirect:/purchase/viewOrder";
	}

	@RequestMapping(path = "/viewOrder", method = RequestMethod.GET)
	public String viewOrder(HttpServletRequest request, HttpServletResponse response) {
		//request.setAttribute("order", new Order());
		return "ViewOrder";
	}

	@RequestMapping(path = "/confirmOrder", method = RequestMethod.POST)
	public String confirmOrder(@ModelAttribute("order") Order order, HttpServletRequest request) {
		request.getSession().setAttribute("order", order);
		return "redirect:/purchase/viewConfirmation";
	}

	@RequestMapping(path = "/viewConfirmation", method = RequestMethod.GET)
	public String viewConfirmation(HttpServletRequest request, HttpServletResponse response) {
		// display order detail.
		return "Confirmation";
	}
}